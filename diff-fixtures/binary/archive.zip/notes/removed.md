# Removed

Only the before side had this file.
