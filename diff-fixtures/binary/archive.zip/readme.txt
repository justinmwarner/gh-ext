archive contents, before side
